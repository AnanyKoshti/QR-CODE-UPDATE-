from flask import Flask, request, render_template, send_from_directory
import qrcode
import os
from PIL import Image

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def home():
    qr_code_path = None
    if request.method == "POST":
        link = request.form["link"]
        img = qrcode.make(link)

        # Ensure static folder exists
        os.makedirs("static", exist_ok=True)

        # Save as PNG
        png_path = os.path.join("static", "qr.png")
        img.save(png_path)

        # Save as JPG
        jpg_path = os.path.join("static", "qr.jpg")
        img = img.convert("RGB")
        img.save(jpg_path, "JPEG")

        # Save as PDF
        pdf_path = os.path.join("static", "qr.pdf")
        img.save(pdf_path, "PDF", resolution=100.0)

        qr_code_path = "qr.png"

    return render_template("index.html", qr_code=qr_code_path)

@app.route("/download/<filetype>")
def download(filetype):
    filename = f"qr.{filetype}"
    return send_from_directory("static", filename, as_attachment=True)

if __name__ == "__main__":
    app.run(debug=True)
